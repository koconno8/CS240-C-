#ifndef COURSE_H
#define COURSE_H
#include <iostream>
#include <stdlib.h>
#include "Roster.h"

using namespace std;

class Course {
   public:
  Course(string name, unsigned int capacity, string instruct);

      Course();

      void show();

   private:
      string courseName = "";
      unsigned int maximumCapacity = 0;
      string instructor = "";
};
// hello
#endif