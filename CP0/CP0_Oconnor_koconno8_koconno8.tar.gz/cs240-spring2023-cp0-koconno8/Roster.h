#include <iostream>
#include <stdlib.h>
using namespace std;

class Roster {
        public:
                Roster(int studCount);

                Roster();

                void show();

        private:
                int numbStudents;
};
