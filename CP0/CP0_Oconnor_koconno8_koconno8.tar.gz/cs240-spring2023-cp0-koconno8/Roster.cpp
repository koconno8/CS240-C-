#include <iostream>
#include <stdlib.h>
#include "Roster.h"
using namespace std;

Roster::Roster(int studCount) {
	this->numbStudents = studCount;
	}
		
Roster::Roster() {
	numbStudents = 0;
	}

void Roster::show() {
	cout << numbStudents;
	}

	

