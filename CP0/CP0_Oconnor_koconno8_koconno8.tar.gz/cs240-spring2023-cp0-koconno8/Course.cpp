#include <iostream>
#include <stdlib.h>
#include "Course.h"
using namespace std;

Course::Course(string name, unsigned int capacity, string instruct) {
         courseName = name;
         maximumCapacity = capacity;
         instructor = instruct;
      }

      Course::Course() {
         courseName = "";
         maximumCapacity = 0;
         instructor = "";
      }

      void Course::show() {
         cout << courseName << " (" << maximumCapacity << "): " << instructor <\
< endl;
      }


