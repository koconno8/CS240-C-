#include <iostream>
#include <stdlib.h>
#include "Course.h"

using namespace std;

int main(int argc, char *argv[]) {
   Course one;
   Course *two = new Course("CS 240", 100, "Dracula");
   Course *three = new Course("MATH 101", 200, "Smirf");
   one.show();
   two->show();
   three->show();
   delete(two);
   delete(three);
}
