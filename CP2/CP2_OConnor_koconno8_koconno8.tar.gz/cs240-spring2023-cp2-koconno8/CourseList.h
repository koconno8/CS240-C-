#ifndef COURSELIST_H
#define COURSELIST_H

#include <iostream>
#include <stdlib.h>

#include "Course.h"
#include "Student.h"

using namespace std;

//class Course;

class CourseList
{
    public:
        CourseList();
        void resize();
        ~CourseList();

        void addCourse(Course* course);  //no list to search for crn so must pass in course
        void removeCourse(Course* course);
        
        void cancelCourse(string crn);
        
        Course* searchByCRN(string crn);

        int getNumberOfCourses();
        int getCapacity();
        Course& getCourse(int index);
        //Course* getCourseList();

    private:
        int capacity;
        int numCourses;
        Course* courses; 
};

#endif
