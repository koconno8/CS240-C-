#include <iostream>
#include <stdlib.h>
#include <vector>
#include <typeinfo>
#include <regex>
#include <string>
#include <iterator>

#include "Course.h"
#include "CourseList.h"
#include "Student.h"
#include "StudentList.h"

using namespace std;

void showPrompt() {
   std::cout << "Enter [\"build <crn> <department> <number> <name>\"" << std::e\
ndl <<
                "       \"cancel <crn>\"" << std::endl <<
                "       \"enroll <bnumber> <userid> <first> <last>\"" << std::e\
ndl <<
                "       \"add <bnumber> <crn>\"" << std::endl <<
                "       \"drop <bnumber> <crn>\"" << std::endl <<
                "       \"roster <crn>\"" << std::endl <<
                "       \"schedule <bnumber>\"" << std::endl <<
                "       \"quit\"]" << endl <<
                ": ";
}

int main(){
    CourseList courses; //Master schedule of all courses in the school
    StudentList enrolledStudents; //creates a list of all students

    
    showPrompt();
    while(true)
    {
        //Step 1: Take in Full Line
        string commandAsLine;
        getline(cin, commandAsLine);

        //Step 2: Split by Space
        vector <string> separatedCommand;
        size_t locationOfSpace;

        while((locationOfSpace = commandAsLine.find(" ")) != string::npos)
        {
            separatedCommand.push_back(commandAsLine.substr(0, locationOfSpace));
            commandAsLine.erase(0,locationOfSpace+1);
        }
        separatedCommand.push_back(commandAsLine);        

        //The user enters build to make a new course in your program.
        if(separatedCommand[0] == "build") 
        {
                                                                                    bool boo = true;
                                                                                    //Number of arguments
                                                                                    if(boo && separatedCommand.size() < 5)
                                                                                    {
                                                                                        cout << "Too Few Arguments" << endl;
                                                                                        boo = false;
                                                                                    }
                                                                                    else if(boo && separatedCommand.size() > 5)
                                                                                    {
                                                                                        cout << "NOTE: More than 5 arguments" << endl;
                                                                                    }
                                                                                    //CRN - Command 1
                                                                                    if(boo && !(regex_match(separatedCommand[1], regex("^(\\d{6})$"))))
                                                                                    {
                                                                                        cout << "Input Error: " <<separatedCommand[1] << " illegal CRN" << endl;
                                                                                        boo = false;
                                                                                    }
                                                                                    //Department - Command 2
                                                                                    if ((boo) &&(!(regex_match(separatedCommand[2], regex("^[A-Z]{2,4}$")))))
                                                                                    {
                                                                                        cout<< "Input Error: " << separatedCommand[2] << " illegal department" << endl;
                                                                                        boo = false;
                                                                                    }
                                                                                    //Course Number - Command 3
                                                                                    //if(boo && (typeid(separatedCommand[3]) != typeid(int)) && separatedCommand[3].length() != 3)
                                                                                    if((boo) && (!(regex_match(separatedCommand[3], regex("^[1-6]{1}[0-9]{2}$")))))
                                                                                    {
                                                                                        cout << "Input Error: " << separatedCommand[3] << " illegal course number" << endl;
                                                                                        boo = false;
                                                                                    }
                                                                                    //Course name
                                                                                    string fullCourseName = "";
                                                                                    for(int i = 4; i < separatedCommand.size() ;i++)
                                                                                    {
                                                                                        fullCourseName += separatedCommand[i];
                                                                                        if(i != separatedCommand.size() -1)
                                                                                        {
                                                                                            fullCourseName += " ";
                                                                                        }
                                                                                    }
            //Anything before the first letter and after the last letter get rid of it
            //Whitespace - convert it to a single space
            if(boo == true)
            {
                if(courses.searchByCRN(separatedCommand[1]) != nullptr) 
                {
                    cout << "Error: Course " << separatedCommand[1] << " already exists" << endl;   
                }
                else
                {
                    Course* newCourse = new Course(separatedCommand[1], separatedCommand[2], separatedCommand[3], fullCourseName);
                    courses.addCourse(newCourse);
                    cout << "Success: built course " << separatedCommand[1] << " " << separatedCommand[2] << " "<< separatedCommand[3]<< " " << fullCourseName << endl;
                }
            }
        }


        //The user enters cancel to remove a course from your program
        else if(separatedCommand[0] == "cancel")
        {
                                                                                        bool boo = true;
                                                                                        if(separatedCommand.size() != 2)
                                                                                        {
                                                                                            cout << "Need 2 arguments!" << endl;
                                                                                            boo = false;
                                                                                        }
                                                                                        //crn
                                                                                        if(boo && !(regex_match(separatedCommand[1], regex("^(\\d{6})$"))))
                                                                                        {
                                                                                            cout << "Input Error: " <<separatedCommand[1] << " illegal CRN" << endl;
                                                                                            boo = false;
                                                                                        }
            if(boo == true)
            {        
                Course* courseToRemove = courses.searchByCRN(separatedCommand[1]);
                if (courseToRemove == nullptr) 
                {
                    cout << "Cannot cancel course " << separatedCommand[1] << ", it doesn't exist" << endl;
                } 
                else
                {
                    courses.removeCourse(courseToRemove);
                    cout << "Success: cancelled course " << separatedCommand[1] << endl;
                }
                for (int i = 0; i < enrolledStudents.getNumStudents(); i++)
                {
                    CourseList* schedule = enrolledStudents.getStudent(i).getCourseList();
                    if (schedule != nullptr)
                    {
                        schedule->removeCourse(courseToRemove);
                    }
                }
            }
        }


        
        
        //The user enters enroll to create a new student in your program
        else if(separatedCommand[0] == "enroll")
        {
                                                                                            bool boo = true;
                                                                                            if(separatedCommand.size() != 5)
                                                                                            {
                                                                                                cout << "Input Error: Too few arguments" << endl;
                                                                                            }
                                                                                            //bnumber
                                                                                            if((boo) && (!(regex_match(separatedCommand[1], regex("^(B[0-9]{8}$)")))))
                                                                                            {
                                                                                                cout << "Input Error: " <<separatedCommand[1] << " illegal BNumber" << endl;
                                                                                                boo = false;
                                                                                            }
                                                                                            //userID
                                                                                            if((boo) && (!(regex_match(separatedCommand[2], regex("^[a-zA-Z][a-zA-Z0-9]*$")))))
                                                                                            {
                                                                                                cout << "Input Error: " <<separatedCommand[2] << "Input Error: Illegal user id" << endl;
                                                                                                boo = false;
                                                                                            }
                                                                                            //First name
                                                                                            if((boo) && (!(regex_match(separatedCommand[3], regex("^([a-zA-Z]+$)")))))
                                                                                            {
                                                                                                cout << "Input Error: " <<separatedCommand[3] << "Input Error: Illegal first name" << endl;
                                                                                                boo = false;
                                                                                            }
                                                                                            //last name
                                                                                            string lastName = "";
                                                                                            for(int i = 4; i < separatedCommand.size() ;i++)
                                                                                            {
                                                                                                lastName += separatedCommand[i];
                                                                                                if(i != separatedCommand.size() -1)
                                                                                                {
                                                                                                    lastName += " ";
                                                                                                }
                                                                                            }
            
            if(boo == true)
            {
                Student newStudent(separatedCommand[1], separatedCommand[2], separatedCommand[3], lastName);
                enrolledStudents.enrollStudent(&newStudent);
                cout << "Success: enrolled student " << separatedCommand[1] << " "<< separatedCommand[2]<< " " << separatedCommand[3]<< " " << lastName << endl;
            }
        }


        //The user enters add to put a student into a course.
        else if(separatedCommand[0] == "add")
        {
                                                                                                bool boo = true;
                                                                                                if(separatedCommand.size() != 3)
                                                                                                {
                                                                                                    cout << "Need 3 arguments!" << endl;
                                                                                                }
                                                                                                //bnum
                                                                                                if((boo) && (!(regex_match(separatedCommand[1], regex("^(B[0-9]{8}$)")))))
                                                                                                {
                                                                                                    cout << "Input Error: " <<separatedCommand[1] << " illegal BNumber" << endl;
                                                                                                    boo = false;
                                                                                                }
                                                                                                //crn
                                                                                                if(boo && !(regex_match(separatedCommand[2], regex("^(\\d{6})$"))))
                                                                                                {
                                                                                                    cout << "Input Error: " << separatedCommand[2] << " illegal CRN" << endl;
                                                                                                    boo = false;
                                                                                                }
            if(boo == true)
            {      
                if(enrolledStudents.searchByBNum(separatedCommand[1]) != nullptr) //searches for a student with the same bnumber
                {
                    if(courses.searchByCRN(separatedCommand[2]) != nullptr) //searches for a course with the same crn IS THIS THE WAY TO SEE IF IT IS IN COURSES?
                    {
                        if(enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->searchByCRN(separatedCommand[2]) != nullptr)
                        {
                            cout << "ERROR: Student " <<  separatedCommand[1] << " is already enrolled in course" << endl;
                        }
                        else
                        {
                            enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->addCourse(courses.searchByCRN(separatedCommand[2]));
                            //cout << enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList().getNumberOfCourses() <<endl;
                            courses.searchByCRN(separatedCommand[2])->addStudent(&separatedCommand[1]);
                            cout << "Success: added student " << separatedCommand[1] << " into course " << separatedCommand[2] << endl;
                        }
                    }  
                    else
                    {
                        cout << "No matching course with that CRN" << endl;
                        //might need break statement
                    }  
                }  
                else
                {
                    cout << "No matching student with that BNumber" << endl; //not good it only needs to go at the end
                    //might need break statement
                }
                
                
            }
        }


        //The user types drop to remove a student from a course.
        else if(separatedCommand[0] == "drop")
        {
                                                                                bool boo = true;
                                                                                if(separatedCommand.size() != 3)
                                                                                {
                                                                                    cout << "Need 3 arguments!" << endl;
                                                                                }
                                                                                //b num
                                                                                if((boo) && (!(regex_match(separatedCommand[1], regex("^(B[0-9]{8}$)")))))
                                                                                {
                                                                                    cout << "Input Error: " <<separatedCommand[1] << " illegal BNumber" << endl;
                                                                                    boo = false;
                                                                                }
                                                                                //CRN
                                                                                if(boo && !(regex_match(separatedCommand[2], regex("^(\\d{6})$"))))
                                                                                {
                                                                                    cout << "Input Error: " << separatedCommand[2] << " illegal course number" << endl;
                                                                                    boo = false;
                                                                                }
            if(boo == true)
            {
                //BASICALLY THE SAME AS ADD?
                if(enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->searchByCRN(separatedCommand[2]) != nullptr) //searches for a student with the same bnumber
                {
                    enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->removeCourse(courses.searchByCRN(separatedCommand[2]));
                        //gets a course (type course)         //removes a student from a course  //gets a student pointer
                    courses.searchByCRN(separatedCommand[2])->removeStudent(&separatedCommand[1]);
                    
                    cout << "Success: removed student " << separatedCommand[1] << " from course " << separatedCommand[2] << endl;
                }
                else
                {
                    cout << "Student is not enrolled in course " << separatedCommand[2];
                }                  
                
            }
        }

        //The roster command should also reject illegal CRN's with an identical error message to the one shown above.
        //Gives the CRN, number of students in the course, and a list of students in the course
        else if(separatedCommand[0] == "roster")
        {
                                                                                    bool boo = true;
                                                                                    if(separatedCommand.size() != 2)
                                                                                    {
                                                                                        cout << "Need 2 arguments!" << endl;
                                                                                    }
                                                                                    //CRN
                                                                                    if(boo && !(regex_match(separatedCommand[1], regex("^(\\d{6})$"))))
                                                                                    {
                                                                                        cout << "Input Error: " << separatedCommand[1] << " illegal course number" << endl;
                                                                                        boo = false;
                                                                                    }
            if(boo == true)
            {
                bool foundCourse = false;
                int courseIndex = -1;
                for (int i = 0; i < courses.getNumberOfCourses(); i++) 
                {
                    if (courses.getCourse(i).getCRN() == separatedCommand[1]) 
                    {
                        foundCourse = true;
                        courseIndex = i;
                        //break;
                    }
                }

                // Print the roster if the course was found
                if (foundCourse) 
                {
                    cout << "CRN: " << courses.getCourse(courseIndex).getCRN() << endl;
                    cout << "Students: " << courses.getCourse(courseIndex).getNumStudents() << endl;
                    for (int i = 0; i < courses.getCourse(courseIndex).getNumStudents(); i++) 
                    {
                        cout << courses.getCourse(courseIndex).getStudentList()[i] << " " << enrolledStudents.searchByBNum(courses.getCourse(courseIndex).getStudentList()[i])->getFirstName() << " " << enrolledStudents.searchByBNum(courses.getCourse(courseIndex).getStudentList()[i])->getLastName() << endl;
                    }
                }       
                else 
                {
                    cout << "No course found with CRN " << separatedCommand[1] << endl;
                }
    
            }
            
        }
            


        //The user enters schedule to display the schedule for an individual student.
        else if(separatedCommand[0] == "schedule")
        {
                                                                                            bool boo = true;
                                                                                            if(separatedCommand.size() != 2)
                                                                                            {
                                                                                                cout << "Need 2 arguments!" << endl;
                                                                                            }
                                                                                            //bnum
                                                                                            if((boo) && (!(regex_match(separatedCommand[1], regex("^(B[0-9]{8}$)")))))
                                                                                            {
                                                                                                cout << "Input Error: " <<separatedCommand[1] << " illegal BNumber" << endl;
                                                                                                boo = false;
                                                                                            }
            if (boo == true)
            {
                if (enrolledStudents.searchByBNum(separatedCommand[1]) != nullptr) 
                {
                    cout << "Student: " << separatedCommand[1] << ": " << enrolledStudents.searchByBNum(separatedCommand[1])->getFirstName() << " " << enrolledStudents.searchByBNum(separatedCommand[1])->getLastName() << endl;
                    for(int i = 0; i < enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->getNumberOfCourses(); i++)
                    {
                        cout << enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->getCourse(i).getCRN() << " " <<
                        enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->getCourse(i).getDepartment() << " " <<
                        enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->getCourse(i).getCourseNumber() << " " <<
                        enrolledStudents.searchByBNum(separatedCommand[1])->getCourseList()->getCourse(i).getCourseName() << endl;
                    }
                }
                else
                {
                    cout << "Error: invalid BNumber" << endl;
                }
            }


            
        }
    
        



        else if(separatedCommand[0] == "quit")
        {
            exit(1);
        }

        else
        {
            cout << "Command not recognized, please try again." << endl;
        }
    }

}
