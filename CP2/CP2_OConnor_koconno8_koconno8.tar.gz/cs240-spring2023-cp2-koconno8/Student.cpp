#include <iostream>
#include <stdlib.h>
#include <vector>
#include <typeinfo>
#include <regex>

#include "Student.h"

using namespace std;

Student::Student()
{
    string first = "";
    string last = "";
    string userID = "";
    string bnum = "";
    capacity = 1;
    numCourses = 0;
    studentSchedule = new CourseList[capacity];
};

Student::Student(string bnum, string userID, string first, string last)
{
    this->bnum = bnum;
    this->userID = userID;
    this->first = first;
    this->last = last;
    this->numCourses = 0;
    this->capacity = 1;
    this->studentSchedule = new CourseList[capacity];

};

Student::Student(const Student& rhs)
{
    this->bnum = rhs.bnum;
    this->userID = rhs.userID;
    this->first = rhs.first;
    this->last = rhs.last;
};

Student& Student::operator=(const Student& other)
{
    if (this != &other) 
    {
        bnum = other.bnum;
        userID = other.userID;
        first = other.first;
        last = other.last;

        delete[] studentSchedule;

        capacity = other.capacity;
        numCourses = other.numCourses;
        
        studentSchedule = new CourseList[capacity];

        for (int i = 0; i < numCourses; i++) 
        {
            studentSchedule[i] = other.studentSchedule[i];
        }
    }
    return *this;
};

Student::~Student()
{   
    delete[] studentSchedule;
};

//getters
string Student::getFirstName()
{
    return first;
};
string Student::getLastName()
{
    return last;
};
string Student::getUserID()
{
    return userID;
};
string Student::getBNumber()
{
    return bnum;
};
CourseList* Student::getCourseList()
{
    return studentSchedule;
};

//setters
void Student::setFirstName(string newFirst)
{
    first = newFirst;
};
void Student::setLastName(string newLast)
{
    last = newLast;
};
void Student::setUserID(string newUserID)
{
    userID = newUserID;
};
void Student::setBNumber(string newBNum)
{
    bnum = newBNum;
};

