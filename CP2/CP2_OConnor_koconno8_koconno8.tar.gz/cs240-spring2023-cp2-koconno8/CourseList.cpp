//SCHEDULE

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <typeinfo>
#include <regex>

#include "CourseList.h"

using namespace std;

CourseList::CourseList()
{
    numCourses = 0;
    capacity = 1;
    //courses = new Course[capacity]; 
    courses = nullptr;

};

//resizes the array
void CourseList::resize()
{
    capacity *= 2;
    Course* new_courses = new Course[capacity];
    for (int i = 0; i < numCourses; i++) 
    {
        new_courses[i] = courses[i];
    }
    delete[] courses;
    courses = new_courses;
};

//deletes the array and frees the memory from courses array
CourseList::~CourseList()
{
    delete[] courses;
};

//adds a course to the given course array
void CourseList::addCourse(Course* course)
{
    if(courses != nullptr)
    {
        if (numCourses == capacity) 
        {
            resize();
        }
        //Course* newCourse = new Course(course);
        courses[numCourses] = *course;
        numCourses++;
    }
    else
    {
        courses = new Course[capacity];
        courses[numCourses] = *course;
        numCourses++;
    }
};

void CourseList::removeCourse(Course* course)
{
    if (courses == nullptr) 
    {
        return;
    }
    int index = -1;
    for (int i = 0; i < numCourses; i++) 
    {
        if (courses[i] == *course) 
        {
            index = i;
            
        }
    }

    // course not found
    if (index == -1) 
    {
        return;
    }
    
    // remove the course
    if (numCourses == 1) // only one course in the array
    {
        numCourses = 0;
        courses = nullptr;
    }
    else
    {
        for (int i = index; i < numCourses - 1; i++)
        {
            courses[i] = courses[i+1];
        }
        numCourses--;
    }
    
};

//removes a course from the given course array
void CourseList::cancelCourse(string crn) 
{
    for(int i = 0; i < numCourses; i++)
    {
        if(courses[i].getCRN() == crn)
        {
            for(int j = i; j < numCourses - 1; j++)
            {
                courses[j] = courses[j + 1]; //loops through and shifts
            }
            numCourses --;
            break;
        }
    }
};

//searches the courses array for a Course object with the given crn
Course* CourseList::searchByCRN(string crn)
{
    for (int i = 0; i < numCourses; i++) 
    {
        if (courses[i].getCRN() == crn) 
        {
            return &(courses[i]);
        }
    }
    return nullptr;
};

int CourseList::getNumberOfCourses()
{
    return numCourses;
};

int CourseList::getCapacity()
{
    return capacity;
};

Course& CourseList::getCourse(int index)
{
    return courses[index];
};
