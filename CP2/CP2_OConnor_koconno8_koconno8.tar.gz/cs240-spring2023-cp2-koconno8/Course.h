#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include <stdlib.h>

//#include "Student.h"

using namespace std;

//since it only uses pointers only need to declare the class
//class Student;
class Course
{
    public:
        Course();
        Course(string crn, string department, string number, string name);
        Course(const Course& rhs);
        ~Course();
        Course& operator=(const Course& other);
        bool operator==(const Course& other);
        
        void resize();

        void addStudent(string* bnum);
        void removeStudent(string* bnum);

        //get
        string getCRN(); 
        string getDepartment(); 
        string getCourseNumber();
        string getCourseName();
        int getNumStudents();

        string* getStudentList();

        //set
        void setCRN(string newCRN);
        void setDepartment(string newDepartment);
        void setCourseNumber(string newNumber);
        void setCourseName(string newName);

    private:
        string crn;
        string department;
        string number;
        string name;

        //new additions
        int studentCapacity;
        int numStudents;
        //Student* students;
        string* students;
};

#endif
