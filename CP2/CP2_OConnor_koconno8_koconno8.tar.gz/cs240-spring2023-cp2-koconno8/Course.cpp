#include <iostream>
#include <stdlib.h>
#include <vector>
#include <typeinfo>
#include <regex>

#include "Course.h"
//#include "Student.h"

using namespace std;

Course::Course()
{
    crn = "";
    department= "";
    number = "";
    name = "";

    
    studentCapacity = 5;
    numStudents = 0;
    students = new string[studentCapacity];
    //students = nullptr;
};

Course::Course(const Course& rhs)
{
    crn = rhs.crn;
    department = rhs.department;
    number = rhs.number;
    name = rhs.name;
};

Course::Course(string crn, string department, string number, string name)
{
    this->crn = crn;
    this->department = department;
    this->number = number;
    this->name = name;
    this->studentCapacity = 1;
    this->numStudents = 0;
    this->students = new string[studentCapacity];
};

Course::~Course()
{   
    delete[] students;
};

Course& Course::operator=(const Course& other)
{
    if (this != &other) 
    {
        name = other.name;
        crn = other.crn;
        department = other.department;
        number = other.number;

        delete[] students;//check to see if null ptr

        studentCapacity = other.studentCapacity;
        numStudents = other.numStudents;

        students = new string[studentCapacity];
        for (int i = 0; i < numStudents; i++) 
        {
            students[i] = other.students[i];
        }
    }
    return *this;
};

bool Course::operator==(const Course& other) 
{
    return crn == other.crn;
};

void Course::resize()
{
    studentCapacity *= 2;
    string* new_students = new string[studentCapacity];
    for (int i = 0; i < numStudents; i++)
    {
        new_students[i] = students[i];
    }
    delete[] students;
    students = new_students;
};

void Course::addStudent(string* bnum)
{
    if(students == nullptr)
    {
        students = new string[studentCapacity];
    }
    if (numStudents == studentCapacity) 
    {
       resize();
    }
    students[numStudents] = *bnum;
    numStudents++;
};

void Course::removeStudent(string* bnum)
{
    int index = -1;
    for (int i = 0; i < numStudents; i++) {
        if (students[i] == *bnum) {
            index = i;
            break;
        }
    }

    // If the student was found, remove it by shifting all the courses after it to the left
    if (index != -1) {
        for (int i = index; i < numStudents - 1; i++) {
            students[i] = students[i+1];
        }
        numStudents--;
    }
};


//getters
string Course::getCRN() 
{
    return crn;
};
string Course::getDepartment() 
{
    return department;
};
string Course::getCourseNumber() 
{
    return number;
};
string Course::getCourseName() 
{
    return name;
};

string* Course::getStudentList()
{
    return students;
};

int Course::getNumStudents()
{
    return numStudents;
};

//setters
void Course::setCRN(string newCRN)
{
    crn = newCRN;
};
void Course::setDepartment(string newDepartment)
{
    department = newDepartment;
};
void Course::setCourseNumber(string newNumber)
{
    number = newNumber;
};
void Course::setCourseName(string newName)
{
    name = newName;
};
