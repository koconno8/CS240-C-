#ifndef STUDENTLIST_H
#define STUDENTLIST_H

#include <iostream>
#include <stdlib.h>
#include <string>

#include "Student.h"

using namespace std;

class StudentList
{
    public:
        StudentList();
        ~StudentList();
        void resize();

        Student* searchByBNum(string bnum);

        void addStudent(Student* student);
        
        void enrollStudent(Student *student); //into StudentList
        void removeStudent(Student *student);

        int getNumStudents();
        int getCapacity();
        Student* getStudentList();
        Student& getStudent(int index);

    private:
        int capacity;
        int numStudents;

        Student* studentArray;
       

};

#endif
