#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <stdlib.h>

#include "CourseList.h"

using namespace std;

class CourseList;
class Student
{
    public:
        Student();
        Student(string bnum, string userID, string first, string last);
        Student(const Student& rhs);
        Student& operator=(const Student& other);
        ~Student();

        //getters
        string getFirstName();
        string getLastName();
        string getUserID();
        string getBNumber();
        CourseList* getCourseList();

        //setters
        void setFirstName(string newFirstName);
        void setLastName(string newLastName);
        void setUserID(string newUserID);
        void setBNumber(string newBNumber);

    private:
        string first;
        string last;
        string userID;
        string bnum; 
        int capacity;
        int numCourses;
        CourseList* studentSchedule; //replace with string array of bnumbers?
};

#endif