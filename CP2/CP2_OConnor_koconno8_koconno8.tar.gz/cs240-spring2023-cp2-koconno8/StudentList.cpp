//ROSTER

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <typeinfo>
#include <regex>

#include "StudentList.h"

using namespace std;

StudentList::StudentList()
{    
    numStudents = 0; //number of people in a specific course
    capacity = 1; //max number of students in a course
    //studentArray = new Student[capacity];
    studentArray = nullptr;
};

//deletes the array
StudentList::~StudentList() 
{
    delete[] studentArray;
};

//resizes the array when there is no more room left in the class
void StudentList::resize()
{
    {
        capacity *= 2;
        Student* new_students = new Student[capacity];
        for (int i = 0; i < numStudents; i++) 
        {
            new_students[i] = studentArray[i];
        }
        delete[] studentArray;
        studentArray = new_students;
    }
};

//searches within the array for a student with a specific bnum
Student* StudentList::searchByBNum(string bnum)
{
    if(studentArray != nullptr) 
    {
        for (int i = 0; i < numStudents; i++) 
        {
            if (studentArray[i].getBNumber() == bnum) 
            {
                return &studentArray[i];
            }
        }
        return nullptr;
    }
    return nullptr;
};

//adds a student to a list
void StudentList::addStudent(Student* student)
{
    if(studentArray != nullptr)
    {
        if (numStudents == capacity) 
        {
            //resize function
            resize();
        }
        studentArray[numStudents] = *student;
        numStudents++;
    }
    //if there is no array, make one
    else
    {
        studentArray = new Student[capacity];
        studentArray[numStudents] = *student;
        numStudents++;
    }
};

//enrolls a student to a student array 
void StudentList::enrollStudent(Student* student) 
{
    if(studentArray != nullptr)
    {
        if( numStudents == capacity)
        {
            resize();
        }
        studentArray[numStudents] = *student;
        numStudents ++;
    }
    else
    {
        studentArray = new Student[capacity];
        studentArray[numStudents] = *student;
        numStudents ++;
    }
};

//removes a student from the array of enrolled students
void StudentList::removeStudent(Student *student) 
{
    if(studentArray != nullptr) 
    {
        int index = 0;
        bool found = false;
        Student* newStudentArray = new Student[numStudents - 1];

        // Copy all of the students except the one removed to a new array
        for (int i = 0; i < numStudents; i++) 
        {
            if (!(studentArray[i].getBNumber() == student->getBNumber())) 
            {
                newStudentArray[index] = studentArray[i];
                index++;
            } 
            else 
            {
                found = true;
            }
        } 
        // Update enrolledStudents and numStudents if student was found
        if (found) 
        {
            delete[] studentArray;
            studentArray = newStudentArray;
            numStudents--;
        } 
        //delete the unused array
        else 
        {
            delete[] newStudentArray;
        }
    }
};

int StudentList::getNumStudents()
{
    return numStudents;
};

int StudentList::getCapacity()
{
    return capacity;
};

Student* StudentList::getStudentList()
{
    return studentArray;
};

Student& StudentList::getStudent(int index)
{
    return studentArray[index];
};